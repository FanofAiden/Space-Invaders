// instructions page at the beginning of the game
let xButton = 555;
let yButton = 620;

let lButton = 200;
let wButton = 100;
let click = 0;
function startUp(){
if(keyCode == 13){ //same thing- if enter is pressed the game begins
	lButton = 150;
  wButton = 80;
	xButton = 595;
  yButton = 620;
	  start = true;
	}
print(start);
}