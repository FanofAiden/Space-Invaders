//reset function do reset the game when you lose all 3 lives
function reset(){

x = 1400/2; //resets the x value of the spaceship
y = 700; //resets the y value of the spaceship
lives=3; //resets the lives back to 3
score2 = score //to tell user what their last score was
score = 0 //to reset score in game
start=false; //sets the game back at false so user can press enter again
}