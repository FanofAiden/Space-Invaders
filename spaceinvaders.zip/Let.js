// declaring variables
let spaceShip; 
let x;
let y;
let xB =x+58;//x placement of bullet
let yB=[2000]; //y placement of bullet
let xMove;
let fire = false;
let score = 0; //initial score
let img;
let xW;
let yW;
let prplAlien;
let blueAlien;
let myAliens=[];
let start = false; //starts the game at false so user can hit enter to play
let lives = 3;
let slider; //volume slider for laser
let slider2; //volume slider for hitmarker on alien
let img2;
let img3;
let img4;
let img5;
score2 = 0;//score for "the last score" system
let highestScore; //high score
highestScore = 0; //initial score